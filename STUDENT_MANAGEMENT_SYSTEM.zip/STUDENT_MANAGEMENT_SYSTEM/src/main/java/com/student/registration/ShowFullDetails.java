package com.student.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/showfulldata")
public class ShowFullDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private final static String query = "select * from student s inner join marks m on s.roll_no=m.roll_no";
	
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		//get PrintWriter
		PrintWriter pw=res.getWriter();
		
		//set content type
		res.setContentType("text/html");
		
		//link the bootstrap
		pw.println("<link rel='stylesheet' href='css/bootstrap.css'></link>");
		pw.println("<marquee><h2 class='text-primary'>Student Full Details</h2></marquee>");
		
		//Load and register the jdbc driver
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		//establish a connection
		try(Connection con=DriverManager.getConnection("jdbc:mysql:///mastercomproject","root","Abhi@2588");
				PreparedStatement pstmt=con.prepareStatement(query))
		{
			//for select we need ResultSet
			ResultSet rs=pstmt.executeQuery();
			
			pw.println("<div style='margin:auto;width:1200px;margin-top:100px;'>");
			pw.println("<table class='table table-hover table-striped'>");
			
			pw.println("<tr>");
			
			//pw.println("<th>Sl.No</th>");
			pw.println("<th>Registration Number</th>");
			pw.println("<th>Roll Number</th>");
			pw.println("<th>Name</th>");
			pw.println("<th>Email</th>");
			pw.println("<th>Gender</th>");
			pw.println("<th>DOB</th>");
			pw.println("<th>Phone</th>");
			pw.println("<th>Course</th>");
			//pw.println("<th>Roll No</th>");
			pw.println("<th>Physics</th>");
			pw.println("<th>Chemistry</th>");
			pw.println("<th>Math</th>");
			pw.println("<th>Biology</th>");
			
			
			pw.println("</tr>");
			while(rs.next())
			{
				pw.println("<tr>");	
				//pw.println("<td>"+rs.getInt(1)+"</td>");
				pw.println("<td>"+rs.getString(1)+"</td>");
				pw.println("<td>"+rs.getString(2)+"</td>");
				pw.println("<td>"+rs.getString(3)+"</td>");
				pw.println("<td>"+rs.getString(4)+"</td>");
				pw.println("<td>"+rs.getString(5)+"</td>");
				pw.println("<td>"+rs.getString(6)+"</td>");
				pw.println("<td>"+rs.getString(7)+"</td>");
				pw.println("<td>"+rs.getString(8)+"</td>");
				//pw.println("<td>"+rs.getString(10)+"</td>");
				pw.println("<td>"+rs.getInt(10)+"</td>");
				pw.println("<td>"+rs.getInt(11)+"</td>");
				pw.println("<td>"+rs.getInt(12)+"</td>");
				pw.println("<td>"+rs.getInt(13)+"</td>");
				
				
				
				
				pw.println("</tr>");	
			}
			pw.println("</table>");
			pw.println("<button class='btn btn-outline-success d-block'><a href='index.jsp'>Home</a></button>");
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}


	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		doGet(req, res);
	}

}
