package com.student.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/editurlmark")
public class EditScreenMarkServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
private final static String query = "select Physics,Chemistry,Math,Biology from marks where roll_no=?";
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		//get PrintWriter
		PrintWriter pw = res.getWriter();
		
		//set content type
		res.setContentType("text/html");
		
		//get the id
		String rollno=req.getParameter("rollno");
		
		//link the bootstrap
		pw.println("<link rel='stylesheet' href='css/bootstrap.css'></link>");
		pw.println("<marquee><h2 class='text-primary'>Student Data Base Edit</h2></marquee>");
		
		//load the JDBC driver
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		//generate the connection
		try(Connection con = DriverManager.getConnection("jdbc:mysql:///mastercomproject","root","Abhi@2588");
				PreparedStatement pstmt = con.prepareStatement(query);)
		{
			//set value
			pstmt.setString(1, rollno);
			
			//for select we neeed resultset
			ResultSet rs=pstmt.executeQuery();
			rs.next();
			pw.println("<div style='margin:auto;width:1200px;margin-top:100px;'>");
			
			//form action for edit
			pw.println("<form action='editmark?rollno="+rollno+"' method='post'>");
			
			pw.println("<table class='table table-hover table-striped'>");
			
			
			
			pw.println("<tr>");
			pw.println("<td>Physics</td>");
			pw.println("<td><input type='text' name='physics' value='"+rs.getInt(1)+"'></td>");
			pw.println("</tr>");
			
			pw.println("<tr>");
			pw.println("<td>Chemistry</td>");
			pw.println("<td><input type='text' name='chemistry' value='"+rs.getInt(2)+"'></td>");
			pw.println("</tr>");
			
			pw.println("<tr>");
			pw.println("<td>Physics</td>");
			pw.println("<td><input type='text' name='math' value='"+rs.getInt(3)+"'></td>");
			pw.println("</tr>");
			
			pw.println("<tr>");
			pw.println("<td>Physics</td>");
			pw.println("<td><input type='text' name='biology' value='"+rs.getInt(4)+"'></td>");
			pw.println("</tr>");
			
			
			
			
			pw.println("<tr>");
			pw.println("<td><button type='submit' class='btn btn-outline-success'>Save</button></td>");
			pw.println("<td><button type='reset' class='btn btn-outline-danger'>Cancel</button></td>");
			pw.println("</tr>");
			
			pw.println("</table>");
			
			pw.println("</form>");
		}
		catch(SQLException se)
		{
			pw.println("<h2 class='bg-danger text-light text-center'>"+se.getMessage()+"</h2>");
			se.printStackTrace();
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		pw.println("<a href='index.jsp'><button class='btn btn-outline-success'>Home</button></a>");
		pw.println("</div>");
		//close the stream
		pw.close();
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req,res);
	}

  
}
